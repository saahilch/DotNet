﻿using EmployeeManagementSystem.Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace EmployeeManagementSystem.Data
{
    public class ApplicationdbContext : DbContext
    {
        public ApplicationdbContext(DbContextOptions options) : base(options)
        {

        }
        public DbSet<Employee> Employees{ get; set; }

    }
}
