﻿using EmployeeManagementSystem.Data;
using EmployeeManagementSystem.Models;
using EmployeeManagementSystem.Models.Entities;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private ApplicationdbContext dbContext;

        public EmployeeController(ApplicationdbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        // For Get All Employees
        [HttpGet]
        public IActionResult GetAllEmployee()
        {
            //var allEmployees=dbContext.Employees.ToList(); 
            return Ok(dbContext.Employees.ToList());
        }


        // Display Employee By Id
        [HttpGet]

        [Route("{id:guid}")]

        public IActionResult GetEmployeeById(Guid id)
        {
            var employee = dbContext.Employees.Find(id);
            if (employee == null)
            {
                return NotFound();
            }

            return Ok(employee);
        }

        // Add Employee

        [HttpPost]

        public IActionResult AddEmployee(AddEmployeeDto addemployeedto)
        {
            var employeeEntity = new Employee()
            {
                Name = addemployeedto.Name,
                Email = addemployeedto.Email,
                Phone = addemployeedto.Phone,
                Salary = addemployeedto.Salary

            };
            dbContext.Employees.Add(employeeEntity);
            dbContext.SaveChanges();
            return Ok(employeeEntity);
        }


        // Update Employee 
        [HttpPut]

        public IActionResult UpdateEmployee(Guid id ,UpdateEmployeeDto updateEmployeeDto )
        {
            var employee =dbContext.Employees.Find(id);
            if (employee == null)
            {
                return NotFound();
            }
            employee.Name = updateEmployeeDto.Name;
            employee.Email=updateEmployeeDto.Email;
            employee.Phone=updateEmployeeDto.Phone;
            employee.Salary=updateEmployeeDto.Salary;

            dbContext.SaveChanges();
            return Ok(employee);
        }
        

        // Delete Employee 

        [HttpDelete]
        [Route("{id:guid}")]
        public IActionResult DeleteEmployee(Guid id)
        {
            var employee = dbContext.Employees.Find(id);
            if(employee == null)
            {
                return NotFound();
            }
            dbContext.Employees.Remove(employee);
            dbContext.SaveChanges();
            return Ok();
        }

    }
}

