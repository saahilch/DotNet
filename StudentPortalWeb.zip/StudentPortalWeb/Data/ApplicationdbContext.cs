﻿using Microsoft.EntityFrameworkCore;
using StudentPortalWeb.Models.Entity;

namespace StudentPortalWeb.Data
{
    public class ApplicationdbContext :DbContext
    {
        public ApplicationdbContext(DbContextOptions<ApplicationdbContext> options):base(options)
        {
            
        }

        /* Bascilly ApplicatondbContext is the Bridge Between The Application &  Database  */
        // Create A Collection & Also Craete A Db table student.& These refers from the Student Entity.

        public DbSet<Student> Students { get; set; }

    }
}